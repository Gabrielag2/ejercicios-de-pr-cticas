# agenda-contactos-angular2
Primer proyecto usando el framework Angular2,  con un servidor de recursos REST Django. 
