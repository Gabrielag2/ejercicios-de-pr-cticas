export class ErroresContacto{
	public nombre:[string];
	public primer_apellido:[string];
	public segundo_apellido:[string];
	public fecha_nacimiento:[string];
	public telefono_fijo:[string];
	public telefono_movil:[string];
	public email:[string];
	public direccion:[string];
	public puesto:[string];
	public genero:[string];

	constructor(){
		this.nombre=[""];
		this.primer_apellido=[""];
		this.segundo_apellido=[""];
		this.fecha_nacimiento=[""];
		this.telefono_fijo=[""];
		this.telefono_movil=[""];
		this.email=[""];
		this.direccion=[""];
		this.puesto=[""];
		this.genero=[""];
        }

}