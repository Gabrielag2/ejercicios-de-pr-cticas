from django.contrib import admin
from contactos.models import Contacto

admin.site.register(Contacto)

